#!/usr/bin/env python3
"""Optional LIVE Linux regression harness: ordinary user, dummy processes/files only.

No Docker, root setup, services, SSH, mount, credentials or enabled stages.
Unsupported platform/primitives exit77/78, explicitly NOT RUN/BLOCKED, never PASS.
All fixture processes self-expire. No force kill, external process scan or unrelated signal.
"""
from pathlib import Path
import contextlib,copy,importlib.util,json,os,signal,subprocess,sys,tempfile,time
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import common as c

def report_exit(code,reason):
    print(json.dumps({'status':'NOT RUN' if code==77 else 'BLOCKED','reason':reason}))
    raise SystemExit(code)
if sys.platform!='linux':report_exit(77,'Linux subreaper/pidfd kernel regression requires an existing Linux sandbox')
if os.geteuid()==0:report_exit(78,'Run as an existing ordinary Linux user; no root setup/access changes permitted')
spec=importlib.util.spec_from_file_location('owned',ROOT/'scripts/owned-supervisor.py')
owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
try:owned.LinuxOwner().initialize()  # Test harness adopts self-expiring uncertain fixture orphans.
except Exception:report_exit(78,'Required unprivileged subreaper/pidfd primitives unavailable')

def reset():c.PROCESS_STATE.update(unconfirmed_group=None,proof=None,retained_paths=[])
def ready(path):
    end=time.monotonic()+2
    while not path.exists():
        if time.monotonic()>end:raise AssertionError('dummy child readiness timeout')
        time.sleep(.01)
    return json.loads(path.read_text())
def alive(identity):
    try:return c.process_identity(identity['pid'])['starttime']==identity['starttime']
    except FileNotFoundError:return False
def expire(identity):
    end=time.monotonic()+4
    while alive(identity):
        try:
            pid,status=os.waitpid(identity['pid'],os.WNOHANG)
            if pid:return
        except ChildProcessError:pass
        if time.monotonic()>end:raise AssertionError('bounded public fixture did not self-expire; no force kill attempted')
        time.sleep(.01)
def failure(call,kind):
    try:call()
    except kind:return
    raise AssertionError('expected failure did not occur')

results=[]
with tempfile.TemporaryDirectory(prefix='s12-r11-LINUX-PUBLIC-') as tmp:
    root=Path(tmp)
    leaf=root/'public-leaf.py'
    leaf.write_text('''import json,os,signal,sys,time
from pathlib import Path
path=Path(sys.argv[1]);ignore=sys.argv[2]=='ignore'
if ignore:signal.signal(signal.SIGTERM,signal.SIG_IGN)
tail=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()
temporary=path.with_suffix('.tmp')
temporary.write_text(json.dumps({'pid':os.getpid(),'starttime':int(tail[19])}));temporary.replace(path)
for fd in (0,1,2):
 try:os.close(fd)
 except OSError:pass
time.sleep(3)
''')
    unrelated_file=root/'unrelated-signal';unrelated=subprocess.Popen([sys.executable,'-B','-c',
        'import signal,time;from pathlib import Path;signal.signal(signal.SIGTERM,lambda *x:Path('+repr(str(unrelated_file))+').write_text("UNEXPECTED"));time.sleep(12)'])
    identities=[]
    try:
        reset();assert c.run([sys.executable,'-B','-c','print("PUBLIC-NORMAL")'],timeout=1,stop_grace=.3)==b'PUBLIC-NORMAL\n'
        assert c.PROCESS_STATE['proof']['tree_empty_confirmed'] is True
        results.append('normal command; kernel ECHILD proof')
        for scenario in ('leader-exit-orphan','setsid-timeout','ignored-SIGTERM'):
            reset();pidfile=root/(scenario+'.json')
            ignore='ignore' if scenario=='ignored-SIGTERM' else 'normal'
            code='''import subprocess,sys,time
from pathlib import Path
subprocess.Popen([sys.executable,'-B',sys.argv[1],sys.argv[2],sys.argv[3]],start_new_session=True)
p=Path(sys.argv[2]);end=time.monotonic()+1
while not p.exists():
 assert time.monotonic()<end
 time.sleep(.005)
'''+('' if scenario=='leader-exit-orphan' else 'time.sleep(3)\n')
            error=RuntimeError if scenario=='ignored-SIGTERM' else ValueError
            failure(lambda:c.run([sys.executable,'-B','-c',code,str(leaf),str(pidfile),ignore],timeout=1,stop_grace=.3),error)
            identity=ready(pidfile);identities.append(identity)
            proof=c.PROCESS_STATE['proof']
            if scenario!='ignored-SIGTERM':
                assert proof['tree_empty_confirmed'] is True and not alive(identity)
                assert c.PROCESS_STATE['unconfirmed_group'] is None
            else:
                assert proof['tree_empty_confirmed'] is False and alive(identity)
                assert c.PROCESS_STATE['unconfirmed_group'] is not None
                not_dispatched=root/'next-must-not-dispatch'
                failure(lambda:c.run([sys.executable,'-B','-c','from pathlib import Path;Path('+repr(str(not_dispatched))+').touch()']),ValueError)
                assert not not_dispatched.exists()
                originals=copy.deepcopy(c.M['paths']);paths=copy.deepcopy(originals)
                for label,key in (('identity','isolated_identity'),('password','isolated_smoke_password'),('record','isolated_smoke_record')):
                    f=root/('PUBLIC-staged-'+label);c.new_file(f,b'PUBLIC-DUMMY',0o600);paths[key]=str(f)
                regular=c.regular;e={}
                with patch.dict(c.M,{'paths':paths}),patch.object(c,'regular',lambda p,mode=None,owner=0:regular(p,mode,owner=os.getuid())):
                    def hold():
                        with c.managed_staged_inputs(e):pass
                    failure(hold,ValueError)
                assert all(Path(paths[k]).exists() for k in ('isolated_identity','isolated_smoke_password','isolated_smoke_record'))
                assert all(x['status']=='RETAINED' for x in e['staged_input_cleanup'].values())
                # Only after independent observation/reaping of this public self-expiring
                # fixture may the TEST reset its in-memory latch. Operator code has no reset.
                expire(identity)
            results.append(scenario+'; separate-session child accounted for; no false cleanup')

        reset();pidfile=root/'nested.json'
        nested='import sys;sys.path.insert(0,sys.argv[1]);import common;common.run([sys.executable,"-B",sys.argv[2],sys.argv[3],"normal"],timeout=5,stop_grace=.3)'
        failure(lambda:c.run([sys.executable,'-B','-c',nested,str(ROOT/'scripts'),str(leaf),str(pidfile)],timeout=1,stop_grace=1),ValueError)
        identity=ready(pidfile);identities.append(identity)
        assert c.PROCESS_STATE['proof']['tree_empty_confirmed'] is True and not alive(identity)
        results.append('nested common.run supervisors; whole owned tree reaped')

        reset();pidfile=root/'signal.json';out=root/'signal-result.json'
        driver='''import json,sys
from pathlib import Path
sys.path.insert(0,sys.argv[1]);import common
try:common.run([sys.executable,'-B',sys.argv[2],sys.argv[3],'normal'],timeout=5,stop_grace=.3)
except ValueError:Path(sys.argv[4]).write_text(json.dumps(common.PROCESS_STATE))
'''
        p=subprocess.Popen([sys.executable,'-B','-c',driver,str(ROOT/'scripts'),str(leaf),str(pidfile),str(out)])
        identity=ready(pidfile);identities.append(identity)
        p.send_signal(signal.SIGTERM)  # The harness's own still-owned direct dummy driver only.
        assert p.wait(timeout=3)==0
        state=json.loads(out.read_text())
        assert state['proof']['tree_empty_confirmed'] is True and state['unconfirmed_group'] is None and not alive(identity)
        results.append('SIGTERM to caller forwarded; owned descendants confirmed stopped')
        assert unrelated.poll() is None and not unrelated_file.exists()
        results.append('unrelated sibling never signalled')
    finally:
        # No signals to surviving fixtures: they expire themselves, then are reaped.
        for identity in identities:expire(identity)
        unrelated.wait(timeout=14)
        assert not unrelated_file.exists()
        reset()
report={'status':'PASS','live_linux_cases':len(results),'results':results,
        'root_or_privileged_setup':False,'production_Docker_mount_credentials_or_enabled_stages':False,
        'forced_kills':False,'public_fixtures_removed':True}
print(json.dumps(report,indent=2))
