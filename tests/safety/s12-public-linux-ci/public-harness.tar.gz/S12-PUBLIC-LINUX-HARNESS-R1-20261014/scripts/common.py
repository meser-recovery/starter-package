"""Prepared operator helpers. Imports do not perform any operation."""
from pathlib import Path
import base64, contextlib, datetime, hashlib, hmac, json, os, re, selectors, shutil, signal, socket, stat, subprocess, sys, tempfile, time

ROOT = Path(__file__).resolve().parents[1]
M = json.loads((ROOT / 'manifest.json').read_text())
B = json.loads((ROOT / 'planned-inputs/bindings.json').read_text())
OP = ROOT / 'operator-copy/deploy'
sys.path.insert(0, str(OP / 's10a'))
from s12_recovery import validate_recovery, verify_key_copies, verify_confirmation, pairs, sha, need
PROCESS_STATE = {'unconfirmed_group': None, 'proof': None, 'retained_paths': []}
class StageInterrupted(Exception): pass

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def require_process_completion():
    need(PROCESS_STATE['unconfirmed_group'] is None, 'OWNED_PROCESS_TREE_COMPLETION_UNCONFIRMED')

def _supervised_capture(args,data,env,timeout,grace):
    read_fd,write_fd=os.pipe()
    p=None;sel=selectors.DefaultSelector();handlers={};buffers={'stdout':bytearray(),'stderr':bytearray(),'status':bytearray()}
    reason=None;signal_sent=False;offset=0
    end=None if timeout is None else time.monotonic()+timeout+grace+5
    def stop(why):
        nonlocal reason,signal_sent,end
        reason=reason or why
        end=min(end,time.monotonic()+grace+5) if end is not None else time.monotonic()+grace+5
        if p is not None and not signal_sent:
            signal_sent=True
            try:p.send_signal(signal.SIGTERM)  # Only this still-owned direct supervisor child.
            except ProcessLookupError:pass
    try:
        for signum in (signal.SIGTERM,signal.SIGINT):
            handlers[signum]=signal.signal(signum,lambda number,frame:stop('PARENT_SIGNAL'))
        if reason is not None:
            return b'',{'version':1,'supervisor_pid':None,'child_started':False,'dispatch_attempted':False,
                'supervision_ready':False,'tree_empty_confirmed':True,'command_returncode':None,
                'stop_reason':reason,'signalled_children':0,'adopted_children_reaped':0,
                'error_code':'INTERRUPTED_BEFORE_DISPATCH'},None,reason
        p=subprocess.Popen([sys.executable,'-B','-I',str(ROOT/'scripts/owned-supervisor.py'),
            '--status-fd',str(write_fd),'--timeout','none' if timeout is None else str(timeout),
            '--grace',str(grace),'--',*map(str,args)],
            stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,env=env,start_new_session=True,pass_fds=(write_fd,),bufsize=0)
        PROCESS_STATE['unconfirmed_group']=p.pid
        os.close(write_fd);write_fd=None
        if reason is not None:stop(reason)
        for stream,label in ((p.stdout,'stdout'),(p.stderr,'stderr'),(read_fd,'status')):
            fd=stream if isinstance(stream,int) else stream.fileno()
            os.set_blocking(fd,False);sel.register(fd,selectors.EVENT_READ,label)
        if p.stdin is not None:
            if data:
                os.set_blocking(p.stdin.fileno(),False);sel.register(p.stdin.fileno(),selectors.EVENT_WRITE,'stdin')
            else:p.stdin.close()
        while True:
            for key,event in sel.select(0.05):
                if key.data=='stdin':
                    try:offset+=os.write(key.fd,data[offset:offset+65536])
                    except BrokenPipeError:offset=len(data)
                    if offset==len(data):sel.unregister(key.fd);p.stdin.close()
                else:
                    chunk=os.read(key.fd,65536)
                    if not chunk:sel.unregister(key.fd)
                    elif len(buffers[key.data])+len(chunk) <= (65536 if key.data=='status' else 8*1024*1024):
                        buffers[key.data].extend(chunk)
                    else:stop('OUTPUT_LIMIT')
            code=p.poll()
            labels={key.data for key in sel.get_map().values()}
            if code is not None and 'status' not in labels:
                # A surviving escaped child may hold stdout/stderr open. Do not wait
                # on those streams when the authoritative proof is false/missing.
                try:proof=json.loads(buffers['status'])
                except (ValueError,UnicodeError):proof={}
                if proof.get('tree_empty_confirmed') is not True or not labels:
                    return bytes(buffers['stdout']),proof,p.pid,reason
            if end is not None and time.monotonic()>=end:
                stop('SUPERVISOR_DEADLINE')
                return bytes(buffers['stdout']),{},p.pid,reason
    finally:
        for signum,handler in handlers.items():signal.signal(signum,handler)
        sel.close()
        for fd in (read_fd,write_fd):
            if fd is not None:
                try:os.close(fd)
                except OSError:pass
        if p is not None:
            for stream in (p.stdin,p.stdout,p.stderr):
                if stream is not None:stream.close()

def run(args, *, data=None, env=None, timeout=120, stop_grace=15):
    require_process_completion()
    PROCESS_STATE.update(unconfirmed_group='STARTING_OWNED_SUPERVISOR',proof=None)
    stdout,proof,pid,parent_stop=_supervised_capture(args,data,env,timeout,stop_grace)
    expected={'version','supervisor_pid','child_started','dispatch_attempted','supervision_ready',
              'tree_empty_confirmed','command_returncode','stop_reason','signalled_children',
              'adopted_children_reaped','error_code'}
    valid=(set(proof)==expected and proof['version']==1 and proof['supervisor_pid']==pid and
           type(proof['tree_empty_confirmed']) is bool and type(proof['child_started']) is bool and
           type(proof['dispatch_attempted']) is bool and type(proof['supervision_ready']) is bool)
    PROCESS_STATE['proof']=proof if valid else {'error_code':'SUPERVISOR_PROOF_INVALID'}
    if not valid or proof['tree_empty_confirmed'] is not True:
        raise RuntimeError('OWNED_PROCESS_TREE_COMPLETION_UNCONFIRMED')
    PROCESS_STATE['unconfirmed_group']=None
    need(proof['error_code'] is None and proof['supervision_ready'] and proof['child_started'], 'SUPERVISION_UNAVAILABLE_BEFORE_DISPATCH')
    need(parent_stop is None and proof['stop_reason'] is None,'CHILD_OPERATION_INTERRUPTED_OR_TIMED_OUT')
    need(type(proof['command_returncode']) is int and proof['command_returncode']==0,'SUBPROCESS_FAILED')
    return stdout

def regular(p, mode=None, owner=0):
    p = Path(p)
    need(p.resolve() == p and not any(x.is_symlink() for x in (p, *p.parents)), 'UNSAFE_PATH')
    s = p.lstat()
    need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_size > 0 and s.st_uid == owner, 'UNSAFE_FILE')
    if owner == 0: need(s.st_gid == 0, 'UNSAFE_ROOT_FILE_GROUP')
    if mode is not None: need(stat.S_IMODE(s.st_mode) == mode, 'UNSAFE_FILE_MODE')
    return p

def private_dir(p, *, create=False):
    p = Path(p)
    need(p.is_absolute() and not any(x.is_symlink() for x in (p, *p.parents)), 'UNSAFE_DIRECTORY_PATH')
    if create and not p.exists(): p.mkdir(mode=0o700)
    s = p.lstat()
    need(stat.S_ISDIR(s.st_mode) and s.st_uid == s.st_gid == 0 and stat.S_IMODE(s.st_mode) == 0o700, 'UNSAFE_PRIVATE_DIRECTORY')
    return p

def new_file(p, data, mode=0o600):
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as f:
        os.fchmod(f.fileno(),mode)  # Exact rights on this newly created fd, independent of umask.
        f.write(data); f.flush(); os.fsync(f.fileno())

def write_record(p, value):
    new_file(p, (json.dumps(value, sort_keys=True, indent=2) + '\n').encode())

def inputs_complete():
    need(B.get('approved') is True, 'BINDINGS_NOT_REVIEWED')
    for section, fields in {
        'isolated': ('address','hostname','machine_id','operator','existing_access_description','isolation_attestation','network_policy_attestation','tls_topology_attestation','tls_certificate_spki_sha256','custody_cleanup_attestation'),
        'custody': ('owner','operator_host','private_identity_path'),
        'zoom': ('approved_meeting_input_ref','existing_credentials_secure_source','scope_owner'),
        'smoke': ('retained_source_path','expected_bytes','expected_sha256','existing_auth_secure_source','expected_settings_dto_sha256','settings_mode')
    }.items():
        need(all(B[section].get(k) is not None and B[section][k] != '' for k in fields), 'MISSING_BINDINGS:' + section)
    need(B['isolated']['hostname'] != 'vmhome' and B['isolated']['address'] not in ('192.168.1.50','192.168.1.150'), 'PRODUCTION_IS_NOT_ISOLATED')
    need(B['custody']['private_identity_path'] == M['custody_identity_path_known'], 'CUSTODY_PATH_CHANGED')
    s = B['smoke']
    need(s['settings_mode'] == 'absent', 'R1_ONLY_ACCEPTS_PINNED_ABSENT_CIPHERTEXT')
    need(re.fullmatch(r'/v1/source-sessions/[0-9a-f-]{36}/blobs/[0-9a-f-]{36}/parts/[0-9]+/content',s['retained_source_path']), 'INVALID_SOURCE_INPUT_ROUTE')
    need(isinstance(s['expected_bytes'],int) and 0 < s['expected_bytes'] <= 64*1024*1024, 'UNBOUNDED_SOURCE_INPUT')
    need(all(re.fullmatch('[0-9a-f]{64}',s[k]) for k in ('expected_sha256','expected_settings_dto_sha256')), 'INVALID_SMOKE_EXPECTATION_HASH')

def once(stage, isolated=False):
    need(os.geteuid() == os.getegid() == 0, 'ROOT_REQUIRED')
    state = private_dir(M['paths']['isolated_state' if isolated else 'production_state'], create=True)
    new_file(state / (stage + '.attempted'), (utc() + '\n').encode())
    return state

def receipt(state, stage, value):
    write_record(state / (stage + '.json'), dict(value, finished_utc=utc(), repeat_allowed=False))

def successful(state, stage):
    r = json.loads(regular(state / (stage + '.json'), 0o600).read_text())
    need(r['status'] == 'PASS', 'PREREQUISITE_NOT_PASS:' + stage)
    return r

def production_baseline():
    p = M['production']; need(socket.gethostname() == p['hostname'], 'WRONG_PRODUCTION_HOST')
    engine = json.loads(run(['docker','info','--format','{{json .}}']))
    need(engine['ServerVersion'] == M['baseline_engine']['docker'] and engine['OSType'] == 'linux' and engine['Architecture'] in ('amd64','x86_64'), 'PRODUCTION_ENGINE_DRIFT')
    need(['driver-type',M['baseline_engine']['store']] in engine['DriverStatus'], 'PRODUCTION_STORE_DRIFT')
    need(run(['docker','compose','version','--short']).decode().strip() == M['baseline_engine']['compose'], 'PRODUCTION_COMPOSE_DRIFT')
    need(sha(regular(p['runtime'], 0o600)) == p['runtime_sha256'] and pairs(Path(p['runtime'])) == p['runtime_values'], 'RUNTIME_DRIFT')
    for name, expected in p['configs'].items():
        if not expected['present']: need(not os.path.lexists(name), 'UNEXPECTED_OVERLAY')
        else: need(sha(regular(name, int(expected['mode'], 8))) == expected['sha256'], 'CONFIG_DRIFT')
    recipient = regular(p['recipient_file'], 0o644).read_text().strip()
    need(recipient == p['recipient'], 'RECIPIENT_DRIFT')
    ids = {}
    for service, field in [('gateway','gateway_image_id'), ('caddy','caddy_frontend_image_id')]:
        lines = run(['docker','ps','-q','--filter','label=com.docker.compose.project=' + p['project'],'--filter','label=com.docker.compose.service=' + service]).decode().splitlines()
        need(len(lines) == 1, 'AMBIGUOUS_LIVE_CONTAINER')
        c = json.loads(run(['docker','inspect',lines[0]]))[0]
        need(c['State']['Running'] and c['Image'] == p['identity'][field], 'RUNNING_IMAGE_DRIFT')
        ids[service] = c['Id']
    return ids

def archive_absent(ids):
    # Fixed prepared probe: transient contents:read token, no token/response body logging.
    r = json.loads(run(['docker','exec','-i',ids['gateway'],'node','--input-type=module'],
                       data=(ROOT / 'scripts/archive-absent-probe.mjs').read_bytes(), timeout=75))
    need(r == {'status':'PASS','head':M['production']['archive_head'],'settings':'absent','archiveWrites':0}, 'ARCHIVE_HEAD_OR_SETTINGS_DRIFT')

def copy_secret(src, dst):
    regular(src, 0o640)
    new_file(dst, Path(src).read_bytes())

@contextlib.contextmanager
def managed_staged_inputs(evidence):
    """Own only the three fixed staged copies, never external custody/auth sources."""
    specs={label:Path(M['paths'][key]) for label,key in (
        ('identity','isolated_identity'),('password','isolated_smoke_password'),('record','isolated_smoke_record'))}
    adopted={};states={label:{'status':'NOT_ADOPTED','reason':'PREFLIGHT_NOT_REACHED'} for label in specs}
    evidence['staged_input_cleanup']=states
    try:
        # Adopt all safely staged files before any recipient/password/record content check.
        for label,path in specs.items():
            try:
                regular(path,0o600);s=path.lstat()
                adopted[label]=(path,s.st_dev,s.st_ino)
                states[label]={'status':'MANAGED; cleanup pending'}
            except FileNotFoundError:states[label]={'status':'NOT_ADOPTED','reason':'STAGED_COPY_MISSING'}
            except (OSError,ValueError):states[label]={'status':'RETAINED','reason':'STAGED_COPY_METADATA_REFUSED'}
        need(len(adopted)==len(specs),'STAGED_INPUT_ADOPTION_INCOMPLETE')
        yield specs
    finally:
        for label,(path,device,inode) in adopted.items():
            if PROCESS_STATE['unconfirmed_group'] is not None:
                states[label]={'status':'RETAINED','reason':'OWNED_PROCESS_TREE_COMPLETION_UNCONFIRMED'}
                PROCESS_STATE['retained_paths'].append(str(path));continue
            try:
                if not os.path.lexists(path):states[label]={'status':'ALREADY_ABSENT'};continue
                regular(path,0o600);s=path.lstat()
                need((s.st_dev,s.st_ino)==(device,inode),'STAGED_COPY_IDENTITY_CHANGED')
                path.unlink();states[label]={'status':'REMOVED'}
            except (OSError,ValueError):
                states[label]={'status':'RETAINED','reason':'STAGED_COPY_CHANGED_OR_UNLINK_REFUSED'}
        evidence['isolated_private_identity_password_record_cleanup']=(
            'PASS' if len(states)==3 and all(x['status'] in ('REMOVED','ALREADY_ABSENT') for x in states.values())
            else 'INCOMPLETE; see per-input retention reason')
        if evidence['isolated_private_identity_password_record_cleanup']!='PASS' and sys.exc_info()[0] is None:
            raise ValueError('STAGED_INPUT_CLEANUP_INCOMPLETE')

def process_identity(pid):
    # Kernel metadata only: no cmdline, environment or shell history.
    text=Path('/proc/'+str(pid)+'/stat').read_text()
    tail=text[text.rfind(')')+2:].split()
    return {'pid':int(pid),'ppid':int(tail[1]),'starttime':int(tail[19])}

def service_secret_metadata():
    result = {}
    for name in ('github-app.pem','session-signing-secret','shared-password-verifier'):
        s = regular(Path(M['production']['config']) / name,0o640).stat()
        result[name] = dict(device=s.st_dev,inode=s.st_ino,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
    return result

def snapshot_matches_live(secret):
    for name in ('github-app.pem','session-signing-secret','shared-password-verifier'):
        live = regular(Path(M['production']['config']) / name,0o640).read_bytes()
        need(hmac.compare_digest(live,regular(secret / name,0o600).read_bytes()), 'SERVICE_SECRET_CHANGED_DURING_SNAPSHOT')

@contextlib.contextmanager
def secret_input(with_key=False):
    stage = Path(tempfile.mkdtemp(prefix='meser-s12-pr-r1.', dir='/run'))
    try:
        secret = stage / 'inputs'; secret.mkdir(mode=0o700)
        for name in ('github-app.pem','session-signing-secret','shared-password-verifier'):
            copy_secret(Path(M['production']['config']) / name, secret / name)
        if with_key:
            config = Path(M['production']['config'])
            verify_key_copies(config)
            new_file(secret / 'archive-settings-key', regular(config / 'archive-settings-key', 0o600).read_bytes())
            verify_key_copies(config, secret)
        yield stage, secret
    finally:
        if PROCESS_STATE['unconfirmed_group'] is None:
            shutil.rmtree(stage)  # Only this newly-created private staging tree.
        else:PROCESS_STATE['retained_paths'].append(str(stage))

def mount_info():
    require_process_completion()
    p = subprocess.run(['findmnt','--json','--mountpoint',M['recovery']['target'],'--output','TARGET,SOURCE,FSTYPE,VFS-OPTIONS,ID'], capture_output=True, text=True)
    if p.returncode == 1 and not p.stdout and not p.stderr: return None
    need(p.returncode == 0, 'MOUNT_LOOKUP_FAILED')
    fs = json.loads(p.stdout)['filesystems']; need(len(fs) == 1, 'AMBIGUOUS_MOUNT'); return fs[0]

@contextlib.contextmanager
def recovery_rw(evidence):
    r = M['recovery']; p = Path(r['target']); info = None; dispatched = False
    # Caller is launched by unshare --mount --propagation private.
    need(os.readlink('/proc/self/ns/mnt') != os.readlink('/proc/1/ns/mnt'), 'PRIVATE_NAMESPACE_REQUIRED')
    need(p.is_dir() and p.resolve() == p and p.stat().st_uid == p.stat().st_gid == 0, 'UNSAFE_MOUNT_TARGET')
    need(mount_info() is None and not any(p.iterdir()), 'TARGET_NOT_EMPTY_OR_MOUNTED')
    existing = subprocess.run(['findmnt','--noheadings','--source',r['source']], capture_output=True)
    need(existing.returncode == 1 and not existing.stdout and not existing.stderr, 'EXPORT_ALREADY_MOUNTED_OR_LOOKUP_ERROR')
    try:
        dispatched = True
        run(['mount','-n','-t','nfs','-o',r['rw_flags'],r['source'],r['target']], timeout=None)
        info = mount_info(); need(info and info['source'] == r['source'] and info['fstype'] == 'nfs4', 'WRONG_NFS')
        need({'rw','nosuid','nodev','noexec'} <= set(info['vfs-options'].split(',')), 'RW_FLAGS_MISMATCH')
        need(regular(p / '.meser-recovery-target').read_text().rstrip('\r\n') == r['marker'], 'MARKER_MISMATCH')
        evidence.update(mount=info, marker='PASS', mount_attempts=1)
        yield p
    finally:
        if dispatched:
            require_process_completion()  # No cleanup syscall while an owned tree is unconfirmed.
            now = mount_info()
            if now is not None:
                need(now['source'] == r['source'] and (info is None or now['id'] == info['id']), 'CLEANUP_IDENTITY_MISMATCH')
                run(['umount','-n','--',r['target']], timeout=None)
                need(mount_info() is None, 'ORDINARY_UNMOUNT_FAILED')
                evidence['ordinary_unmount'] = 'PASS'

def create_bundle(release, secret, runtime, destination, evidence):
    before = set(destination.iterdir())
    run(['/bin/bash',OP / 'recovery/create-recovery-bundle.sh',release,secret,runtime,destination,
         M['production']['recipient'],M['recovery']['marker'],M['recovery']['failure_domain']], timeout=None)
    added = set(destination.iterdir()) - before
    need(len(added) == 1, 'AMBIGUOUS_NEW_BUNDLE')
    bundle = added.pop(); record = validate_recovery(bundle)
    evidence['bundle'] = {'name':bundle.name,'sha256sums':sha(bundle / 'SHA256SUMS'),'source_sha':record['source_sha'],'source_tree':record['source_tree'],'key_version':record.get('settings_key_version','0')}
    return bundle

def isolated_baseline():
    t = B['isolated']; need(socket.gethostname() == t['hostname'] != 'vmhome', 'WRONG_ISOLATED_HOST')
    need(Path('/etc/machine-id').read_text().strip() == t['machine_id'], 'ISOLATED_MACHINE_ID_MISMATCH')
    os_release = Path('/etc/os-release').resolve()
    need(os_release in (Path('/etc/os-release'),Path('/usr/lib/os-release')), 'UNEXPECTED_OS_RELEASE_PATH')
    need(pairs(regular(os_release))['VERSION_ID'].strip('"') == '24.04', 'ISOLATED_OS_MISMATCH')
    engine = json.loads(run(['docker','info','--format','{{json .}}']))
    need(engine['ServerVersion'] == '29.6.2' and engine['OSType'] == 'linux' and engine['Architecture'] in ('amd64','x86_64'), 'ISOLATED_ENGINE_MISMATCH')
    need(['driver-type','io.containerd.snapshotter.v1'] in engine['DriverStatus'], 'ISOLATED_STORE_MISMATCH')
    need(run(['docker','compose','version','--short']).decode().strip() == '5.3.1', 'ISOLATED_COMPOSE_MISMATCH')
    need(not Path('/etc/meser-audio-archive').exists(), 'ISOLATED_CONFIG_NOT_EMPTY')
    need(not run(['docker','ps','-aq','--filter','label=com.docker.compose.project=meser-audio-archive']).strip(), 'ISOLATED_PROJECT_NOT_EMPTY')
    # A reviewed local TLS topology/certificate must exist before restore; no TLS setup is inferred.
    need(re.fullmatch(r'sha256//[A-Za-z0-9+/]{43}=',t['tls_certificate_spki_sha256']), 'TLS_PIN_NOT_BOUND')
    return dict(os.environ, MESER_ISOLATED_TLS_PIN=t['tls_certificate_spki_sha256'])

def bundle_input(version):
    item = B['future_bundle_bindings']['v' + version]
    need(isinstance(item, dict) and set(item) == {'name','sha256sums'}, 'FUTURE_BUNDLE_NOT_BOUND')
    need(re.fullmatch(r'meser-service-recovery-[0-9]{8}T[0-9]{6}Z-[0-9a-f]{40}', item['name']), 'INVALID_BUNDLE_NAME')
    bundle = Path(M['paths']['isolated_inbox']) / item['name']
    need(sha(bundle / 'SHA256SUMS') == item['sha256sums'], 'TRANSFERRED_BUNDLE_PIN_MISMATCH')
    m = validate_recovery(bundle); need(m.get('settings_key_version','0') == version, 'WRONG_BUNDLE_VERSION')
    source = M['production']['identity']['source_sha'] if version == '0' else json.loads((ROOT / 'artifact-locks.json').read_text())['releases'][0]['manifest']['source_sha']
    need(m['source_sha'] == source, 'WRONG_RESTORE_SOURCE')
    return bundle
