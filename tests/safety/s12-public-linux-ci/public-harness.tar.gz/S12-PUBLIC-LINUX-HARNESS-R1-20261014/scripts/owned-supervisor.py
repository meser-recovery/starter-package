#!/usr/bin/env python3
"""Per-invocation Linux subreaper. No service, credentials, root or cgroup setup.

Only direct children are signalled through pidfds, before this sole reaper can
release their PIDs. Orphans (including setsid/double-fork descendants) are adopted
by the subreaper. ECHILD is the completion proof; an empty PID list is not.
"""
import argparse, ctypes, json, os, signal, subprocess, sys, time
from pathlib import Path

class LinuxOwner:
    def initialize(self):
        if sys.platform != 'linux' or not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal'):
            raise RuntimeError('LINUX_SUBREAPER_PIDFD_REQUIRED')
        self.children_path = Path('/proc/self/task') / str(os.getpid()) / 'children'
        if self.children(): raise RuntimeError('SUPERVISOR_NOT_FRESH')
        signal.signal(signal.SIGCHLD,signal.SIG_DFL)
        libc = ctypes.CDLL(None,use_errno=True)
        if libc.prctl(36,ctypes.c_ulong(1),0,0,0) != 0:
            raise RuntimeError('SUBREAPER_UNAVAILABLE')
        value = ctypes.c_int()
        if libc.prctl(37,ctypes.byref(value),0,0,0) != 0 or value.value != 1:
            raise RuntimeError('SUBREAPER_NOT_CONFIRMED')
        fd = os.pidfd_open(os.getpid(),0)
        try: signal.pidfd_send_signal(fd,0,None,0)
        finally: os.close(fd)

    def children(self):
        words = self.children_path.read_text().split()
        if not all(x.isdigit() for x in words): raise RuntimeError('OWNED_CHILD_LOOKUP_FAILED')
        return [int(x) for x in words]

    def reap(self):
        reaped = []
        while True:
            try: pid,status = os.waitpid(-1,os.WNOHANG)
            except ChildProcessError: return reaped,True
            if pid == 0: return reaped,False
            reaped.append((pid,os.waitstatus_to_exitcode(status)))

    def terminate_direct(self,signalled):
        for pid in self.children():
            if pid in signalled: continue
            # This single-threaded supervisor has not reaped the child yet;
            # it cannot be replaced by an unrelated process with a reused PID.
            fd = os.pidfd_open(pid,0)
            try:
                if pid not in self.children(): raise RuntimeError('OWNERSHIP_NOT_CONFIRMED')
                try: signal.pidfd_send_signal(fd,signal.SIGTERM,None,0)
                except ProcessLookupError: pass  # Zombie still belongs to this reaper.
                signalled.add(pid)
            finally: os.close(fd)

def supervise(command,timeout,grace,*,owner_factory=LinuxOwner,popen_factory=subprocess.Popen,
              clock=time.monotonic,pause=time.sleep,install_signals=True):
    record = {'version':1,'supervisor_pid':os.getpid(),'child_started':False,
              'dispatch_attempted':False,
              'supervision_ready':False,'tree_empty_confirmed':False,
              'command_returncode':None,'stop_reason':None,'signalled_children':0,
              'adopted_children_reaped':0,'error_code':None}
    owner = owner_factory(); command_process = None; signalled = set()
    stop = {'reason':None,'deadline':None}; old_handlers = {}
    def request(reason):
        if stop['reason'] is None:
            stop.update(reason=reason,deadline=clock()+grace)
    def handle(signum,frame): request('SIGTERM' if signum==signal.SIGTERM else 'SIGINT')
    try:
        owner.initialize(); record['supervision_ready']=True
        if install_signals:
            for signum in (signal.SIGTERM,signal.SIGINT):
                old_handlers[signum]=signal.signal(signum,handle)
        if stop['reason'] is not None:
            record.update(tree_empty_confirmed=True,stop_reason=stop['reason'],error_code='INTERRUPTED_BEFORE_DISPATCH')
            return record
        record['dispatch_attempted']=True
        command_process = popen_factory(command,stdin=None,stdout=None,stderr=None,
                                        close_fds=True,start_new_session=True)
        record['child_started']=True
        deadline = None if timeout is None else clock()+timeout
        while True:
            reaped,empty = owner.reap()
            for pid,code in reaped:
                signalled.discard(pid)
                if pid==command_process.pid:
                    command_process.returncode=code;record['command_returncode']=code
                else: record['adopted_children_reaped']+=1
            if empty:
                record['tree_empty_confirmed']=True
                break
            if deadline is not None and clock()>=deadline: request('TIMEOUT')
            if record['command_returncode'] is not None: request('ORPHAN_DESCENDANTS')
            if stop['reason'] is not None:
                count=len(signalled)
                owner.terminate_direct(signalled)
                record['signalled_children']+=max(0,len(signalled)-count)
                if clock()>=stop['deadline']:
                    # One final wait distinguishes exited children from an empty lookup.
                    reaped,empty=owner.reap()
                    for pid,code in reaped:
                        if pid==command_process.pid:
                            command_process.returncode=code;record['command_returncode']=code
                        else:record['adopted_children_reaped']+=1
                    record['tree_empty_confirmed']=empty
                    if not empty:record['error_code']='OWNED_TREE_STOP_UNCONFIRMED'
                    break
            pause(0.01)
        record['stop_reason']=stop['reason']
    except Exception:
        # Never infer completion from supervisor/leader exit, stream EOF, or lookup failure.
        if not record['dispatch_attempted']:
            record['tree_empty_confirmed']=True
            record['error_code']='SUPERVISION_UNAVAILABLE_BEFORE_DISPATCH'
        else:
            record['tree_empty_confirmed']=False
            record['error_code']='OWNED_TREE_OBSERVATION_UNCONFIRMED'
    finally:
        for signum,handler in old_handlers.items():signal.signal(signum,handler)
    return record

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--status-fd',type=int,required=True)
    parser.add_argument('--timeout',required=True)
    parser.add_argument('--grace',type=float,default=15)
    parser.add_argument('command',nargs=argparse.REMAINDER)
    args=parser.parse_args()
    # Never pass the authenticated status channel to the command/descendants.
    os.set_inheritable(args.status_fd,False)
    command=args.command[1:] if args.command[:1]==['--'] else args.command
    if not command or args.grace<=0:raise SystemExit(2)
    timeout=None if args.timeout=='none' else float(args.timeout)
    if timeout is not None and timeout<=0:raise SystemExit(2)
    record=supervise(command,timeout,args.grace)
    data=(json.dumps(record,sort_keys=True)+'\n').encode()
    os.write(args.status_fd,data);os.close(args.status_fd)
    raise SystemExit(0 if record['tree_empty_confirmed'] and record['error_code'] is None else 78)

if __name__=='__main__':main()
