"""Strict bundle coverage and private key binding; no network or secret output."""
from pathlib import Path
import hashlib,hmac,json,re,stat

BASE_FILES=set('release-manifest.txt meser-service-source.tar.gz meser-service-source.tar.gz.sha256 gateway-image.tar gateway-image.tar.sha256 caddy-frontend-image.tar caddy-frontend-image.tar.sha256 compose.yaml Caddyfile haproxy.cfg runtime.env secrets.age recovery-manifest.txt RESTORE-RUNBOOK.md'.split())
SECRET_NAMES={'github-app.pem','shared-password-verifier','session-signing-secret','archive-settings-key'}
def need(value,message):
 if not value:raise ValueError(message)
def file(p):
 p=Path(p);s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'unsafe file: '+p.name);return p
def sha(p):
 h=hashlib.sha256()
 with file(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def pairs(p):
 lines=file(p).read_text().splitlines();need(lines and all(x.count('=')==1 for x in lines),'malformed record')
 obj=dict(x.split('=',1) for x in lines);need(len(obj)==len(lines),'duplicate record keys');return obj
def checksum_entries(p):
 entries={}
 for line in file(p).read_text().splitlines():
  m=re.fullmatch(r'([0-9a-f]{64})  ([A-Za-z0-9][A-Za-z0-9._-]*)',line);need(m,'unsafe checksum entry')
  value,name=m.groups();need(name not in entries,'duplicate checksum entry');entries[name]=value
 need(entries,'empty checksum list');return entries
def validate_recovery(root):
 root=Path(root);need(root.is_dir() and root.resolve()==root and not root.is_symlink(),'unsafe bundle')
 m=pairs(root/'recovery-manifest.txt');version=m.get('settings_key_version','0');need(version in ('0','1'),'unknown recovery version')
 expected=BASE_FILES|({'compose.s12.yaml'} if version=='1' else set())
 actual={p.name for p in root.iterdir()};need(actual==expected|{'SHA256SUMS'},'missing or unknown bundle members')
 entries=checksum_entries(root/'SHA256SUMS');need(set(entries)==expected,'incomplete checksum coverage')
 for name in expected:
  need(file(root/name).stat().st_size>0,'empty bundle member');need(sha(root/name)==entries[name],'bundle checksum mismatch')
 for name in ('meser-service-source.tar.gz','gateway-image.tar','caddy-frontend-image.tar'):
  need(checksum_entries(root/(name+'.sha256'))=={name:entries[name]},'archive sidecar mismatch')
 r=pairs(root/'release-manifest.txt')
 for name in ('source_sha','source_tree','gateway_image_id','caddy_frontend_image_id','gateway_image_ref','caddy_frontend_image_ref'):need(m[name]==r[name],'bundle/release identity mismatch')
 need(re.fullmatch('[0-9a-f]{40}',m['source_sha']) and re.fullmatch('[0-9a-f]{40}',m['source_tree']) and m.get('destination_mount_id'),'incomplete recovery identity')
 for key,name in [('compose_sha256','compose.yaml'),('caddy_sha256','Caddyfile'),('haproxy_sha256','haproxy.cfg')]+([('s12_compose_sha256','compose.s12.yaml')] if version=='1' else []):need(r[key]==entries[name],'configuration binding mismatch')
 runtime=pairs(root/'runtime.env');need(runtime['SOURCE_SHA']==r['source_sha'] and runtime['GATEWAY_IMAGE']==r['gateway_image_ref'] and runtime['CADDY_IMAGE']==r['caddy_frontend_image_ref'],'bundle runtime binding mismatch')
 return m
def key_bytes(p,permissions):
 p=file(p);s=p.stat();need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==permissions,'key owner/mode mismatch')
 value=p.read_bytes().strip();need(re.fullmatch(b'[0-9a-fA-F]{64}',value),'invalid key format');return bytes.fromhex(value.decode())
def verify_key_copies(config,backup=None):
 key=key_bytes(config/'archive-settings-key',0o600)
 need(hmac.compare_digest(key,key_bytes(config/'archive-settings-runtime-key',0o640)),'canonical/runtime key mismatch')
 if backup is not None:
  need(backup.resolve()==backup and backup.is_dir() and not backup.is_symlink(),'unsafe backup input')
  need({p.name for p in backup.iterdir()}==SECRET_NAMES,'invalid backup secret members')
  for name in SECRET_NAMES:need(stat.S_IMODE(file(backup/name).stat().st_mode)==0o600,'unsafe backup secret mode')
  need(hmac.compare_digest(key,key_bytes(backup/'archive-settings-key',0o600)),'backup/canonical/runtime key mismatch')
 return key
def confirmation_payload(bundle):
 m=validate_recovery(bundle);need(m.get('settings_key_version')=='1','candidate recovery must be v1')
 return {'type':'s12-candidate-recovery-key-confirmation-v1','source_sha':m['source_sha'],'source_tree':m['source_tree'],'bundle_checksums_sha256':sha(bundle/'SHA256SUMS'),'secrets_age_sha256':sha(bundle/'secrets.age'),'release_manifest_sha256':sha(bundle/'release-manifest.txt')}
def confirmation_mac(payload,key):
 return hmac.new(key,b'meser/s12/off-vm-decrypted-candidate/v1\x00'+json.dumps(payload,sort_keys=True,separators=(',',':')).encode(),hashlib.sha256).hexdigest()
def verify_confirmation(bundle,record,key):
 p=file(record);need(stat.S_IMODE(p.stat().st_mode)==0o600 and p.stat().st_uid==0,'unsafe candidate confirmation')
 actual=json.loads(p.read_text());payload=confirmation_payload(bundle)
 need(set(actual)==set(payload)|{'mac'} and all(actual[k]==v for k,v in payload.items()),'candidate confirmation belongs to another bundle')
 need(isinstance(actual['mac'],str) and hmac.compare_digest(actual['mac'],confirmation_mac(payload,key)),'candidate encrypted key does not match installed key')
