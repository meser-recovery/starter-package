# Public Linux supervisor harness — INSPECTION ONLY / NOT RUN

This is a portable public-dummy test package for an ALREADY EXISTING ordinary-user
Linux sandbox. It creates no user, VM, service, credentials or access. No production,
network, Docker, mounts, private keys or real auth inputs are needed.

Four Python source files are exact immutable copies, pinned in SOURCE-LOCKS.json.
No source or guard was changed. Only unrelated metadata was replaced: manifest.json
is exactly {"paths":{}}; bindings.json is exactly {"approved":false}. The harness
fills its three staged-file paths with PUBLIC-DUMMY files under its own temporary
directory before the only managed-input test. It never calls deployment stages.
common.py retains dormant general helper definitions for byte-identical provenance;
no production wrapper, deployment entrypoint, real manifest or private input is present.

Runtime minimum is six files: the four Python files and two JSON placeholders.
README, SOURCE-LOCKS and SHA256SUMS are inspection/provenance sidecars.

## Exact requirements

- Linux; effective uid must NOT be 0. Root refuses with exit78. Other platform: exit77.
- Existing Python standard library: os.pidfd_open, signal.pidfd_send_signal,
  waitpid/WNOHANG/waitstatus_to_exitcode, subprocess sessions/pass_fds and selectors.
- Readable procfs self/task/<own pid>/children and self/own-child stat/starttime.
- Kernel/libc PR_SET_CHILD_SUBREAPER(36) and PR_GET_CHILD_SUBREAPER(37), pidfds,
  signal0 to self for initialization, and SIGTERM only to the test's owned children.
- A fresh test process with no preexisting children; writable ordinary public temp
  directory. Fixtures self-expire; no SIGKILL, root setup, global PID scan or retry.

Linux uid1000 plus pidfd API presence is a suitable INITIAL CANDIDATE, not live PASS.
Actual setter/syscall/child/reaping behavior remains unverified until a separately
approved one-shot run. Read-only inspection must not import this harness or call
LinuxOwner.initialize(), because those execute test setup / PR_SET_CHILD_SUBREAPER.

Inspect archive SHA and membership; verify SHA256SUMS and SOURCE-LOCKS; ast.parse
all Python sources without importing/executing them. Optional environment inspection
may query PR_GET_CHILD_SUBREAPER(37), procfs readability and open/close a self pidfd.
Do NOT call PR_SET(36), spawn dummy processes or signal children during inspection.

Only after inspection and explicit one-shot approval, the test entrypoint is:

    python3 -B scripts/linux-supervisor-regressions.py

This line is NOT a present execution instruction. It emits JSON on stdout after
seven live cases: normal ECHILD, orphan, setsid timeout, ignored SIGTERM hold,
nested supervisors, caller SIGTERM forwarding and unrelated sibling untouched.
Exit77/78/assertion/cleanup/ownership failures are NOT RUN/BLOCKED/FAILED, never PASS.
No tests or kernel initialization were run while building this package.
